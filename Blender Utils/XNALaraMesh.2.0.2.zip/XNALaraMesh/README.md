XPS Tools 
=========
Blender an addon to Export/Import Haydee assets.

With Blender 2.80 released there where many changes.

From v2.0.0 of this addon will only work with Blender 2.80+ (and viceversa).
For Blender 2.79 download v1.8.5

- Blender 2.80 ==> v2.0.0
- Blender 2.79 ==> v1.8.5

Blender Toolshelf, an addon for Blender to:

Import/Export XPS Models, Poses.

Main Features:
- Imports and Exports XPS/XNALara models with armature.
- Imports and Exports Poses
- Imports and Exports Custom Normals
- Creates Materials on import
- Easily set a new rest pose for the model

more info at:
http://johnzero7.github.io/XNALaraMesh/

